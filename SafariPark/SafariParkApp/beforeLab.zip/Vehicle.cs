﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SafariParkApp
{
    public class Vehicle : IMovable
    {
        protected int _capacity;
        private int _numPassengers;
        public int NumPassengers
        {
            get { return _numPassengers; }
            set { if (value < 0 || value > _capacity) throw new ArgumentException();
                _numPassengers = value;
            }
        }                 

        public int Position { get; set; }
        public int Speed { get; init; }

        public virtual string Move()
        {
            Position += Speed;
            return $"Moving along";
        }

        public virtual string Move(int times)
        {
            Position += Speed * times;
            return $"Moving along {times} times";

        }

        public Vehicle()
        {
        }        

        public Vehicle(int capacity, int speed = 10)
        {
            _capacity = capacity;
            Speed = speed;
        }

        public override string ToString()
        {
            return $"{_capacity}";
        }
    }
}