﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SafariParkApp
{
    public class Person : IMovable
    {
        public string FirstName { get; init; } = "";
        public string LastName { get; init; } = "";
        private int _age;

        public int Age
        {
            get { return _age; }
            set
            {
                if (value < 0 || value > 99)
                {
                    throw new ArgumentException("Invalid age");
                }
                _age = value; 
            }
        }
    
        public Person() {  }

        public Person(string firstname, string lastname, int age = 0)
        {
            FirstName = firstname;
            LastName = lastname;
            Age = age;
        }

        public Person(string firstname)
        {
            FirstName = firstname;
        }

        //public string FullName => $"{FirstName} {LastName}";

        public string GetFullName()
        {
            return $"{FirstName} {LastName}";
        }

        public override string ToString()
        {
            return $"{base.ToString()} Name: {GetFullName()} Age: {Age}";
        }
    }
}